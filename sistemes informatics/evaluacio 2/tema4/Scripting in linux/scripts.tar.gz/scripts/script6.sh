#!/bin/bash

echo "First String" $1;
echo "Second String" $2;
if [ $1 == $2 ]
	then
	echo "The strings are equals"
else
	echo "The strings are differents"

fi
echo "Numbers parametres: " $#
exit 0 

#!/bin/bash

if [ -f $1 ]
	then
	echo "File regular"
elif [ -d $1 ]
	then 
	echo "Directory"

else
	echo "Error, not exist"
fi
exit 0

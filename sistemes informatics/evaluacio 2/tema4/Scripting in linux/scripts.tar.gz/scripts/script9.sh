#!/bin/bash
ls
echo "Name of the file you want to see:" $1
echo "Size    Name"
du -s $1


exit 0

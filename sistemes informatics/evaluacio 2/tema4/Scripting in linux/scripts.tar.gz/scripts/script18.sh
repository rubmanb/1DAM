#!/bin/bash

#functions

function add {
	echo $(($1 + $2))
}
function substract {
	echo $(($1 - $2))
}
function multiply {
	echo $(($1 * $2))
}
function divide {
	echo $(($1 / $2))
}


#calculations

if [ $# -gt 2 ]
	then
	echo "Incorrect parametres passed, I need two."
else
	echo "What do you want to do it?"
	read -p "1 - add | 2 - substract | 3 - multiply | 4 - divide" option
	case "$option" in
		1) value=$(add $1 $2)
		echo "The value of the addition is: $value"
		;;
		2) value=$(substract $1 $2)
		echo "The value of the substraction is: $value"
		;;
		3) value=$(multiply $1 $2)
		echo "The value of the multiplication is: $value"
		;;
		4) value=$(divide $1 $2)
		echo "The value of the division is: $value"
		;;
		*) echo "I need a option correct (1|2|3|4)"
		;;
	esac
fi
exit 0

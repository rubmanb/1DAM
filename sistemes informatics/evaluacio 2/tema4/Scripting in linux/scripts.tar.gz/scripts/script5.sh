#!/bin/bash

#CALCULATOR

echo "Welcome to MyCalculator"
echo "Say me what operation you need"
echo "Addition(1), Substraction(2), Multiplication(3), Division(4)"
read -p "What option do you want to do?" option
echo "Give me 2 numbers and we'll do the most basics arithmetics operations"
read -p "Number one: " a
read -p "Number two: " b

case "$option" in
1)
add=$(( a+b ))
echo "Addition: $add"
;;
2)
subs=$(( a-b ))
echo "Substraction: $subs"
;;
3)
mult=$(( a*b ))
echo "Multiplication: $mult"
;;
4)
div=$(( a/b ))
echo "Division: $div"
;;
*)
echo "Your option is wrong."
;;
esac
 
exit 0

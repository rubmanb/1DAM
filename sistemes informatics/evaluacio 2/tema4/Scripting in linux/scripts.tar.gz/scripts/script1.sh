#!/bin/bash
clear
ls
date

exit 0

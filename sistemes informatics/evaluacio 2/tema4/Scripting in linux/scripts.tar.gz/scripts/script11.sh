#!/bin/bash
echo "Total numbers: "$#
for i in $*
	do
	if (( ($i % 2) == 0 ))
		then
		echo "The number $i is odd"
	else
		echo "The number $i is even"
	fi
done
exit 0

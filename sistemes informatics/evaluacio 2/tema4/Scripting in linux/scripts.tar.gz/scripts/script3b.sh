#!/bin/bash
read -p "Give me 3 numbers in this line" a b c
res=$(( (a+b)/c ))
echo "the result is: $res"

exit 0

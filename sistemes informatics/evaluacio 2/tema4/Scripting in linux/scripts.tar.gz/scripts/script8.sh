#!/bin/bash

echo "Multiplication table of the number: " $1
for (( i=1;i<=10;i++ ))
	do
	let res=$(( $i*$1 ))
	echo $i"X"$1"=$res"
done 
exit 0

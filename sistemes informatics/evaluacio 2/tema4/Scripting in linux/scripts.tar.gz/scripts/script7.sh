#!/bin/bash
echo "This script receive: $# argument"
echo "Name with arg1" $1;
touch $1
ls
read -p "Do you want rename file?(y|n) " option
case "$option" in
y)
read -p "What name?" renamefile
mv $1 "$renamefile"
ls
;;
n)
echo "Bye, See you!"
;;
*)
echo "ERROR the option not is correct"
;;
esac
exit 0

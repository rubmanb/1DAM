#!/bin/bash

list () {
	read -p "Say me a name of a directory:"	name
	if [ -d "$name" ]
		then
		echo "Very good, the directory exist"
		echo "These are the files that directory contains"
		ls -a "$name"
	else
		echo "Sorry, the directory not exist"
	fi
}

list

exit 0

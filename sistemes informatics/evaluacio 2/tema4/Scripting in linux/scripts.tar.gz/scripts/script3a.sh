#!/bin/bash

let res=$(( ($1+$2)/$3 ))

echo "This script return a arithmetic operation: $res"
exit 0

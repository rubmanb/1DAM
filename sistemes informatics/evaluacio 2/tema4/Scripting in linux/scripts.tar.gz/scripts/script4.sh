#!/bin/bash
read -p "Give me 2 numbers to compare: " a b

if [ $a -ne $b ]
	then 
	echo "Its differents."
		if [ $a -gt $b ]
			then 
			res=$(( $a-$b ))
		else
			res=$(( $b-$a ))
		fi
fi
echo "The substract is: $res"

exit 0

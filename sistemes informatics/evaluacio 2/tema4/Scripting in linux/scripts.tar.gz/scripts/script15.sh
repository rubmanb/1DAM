#!/bin/bash

if [ -d $1 ]
	then
	cont=$( ls $1 | wc -l | cut -d' ' -f 1 )
	if [ "$cont" -gt 0 ]
		then
		echo "This directory have files"
	else
		echo "This directory are empty"
	fi
else
	echo "Don't exist"
fi

exit 0

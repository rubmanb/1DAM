#!/bin/bash

arg1=$( wc -l $1 | cut -d' ' -f 1 )
arg2=$( wc -l $2 | cut -d' ' -f 1 )

if [ "$arg1" -gt "$arg2" ]
	then
	echo "The file "$1 "have more lines than "$2
	echo "Lines of the file "$1 $arg1
	echo "Lines of the file "$2 $arg2
elif [ "$arg1" -lt "$arg2" ]
	then
	echo "The file "$1 "have less lines than "$2
	echo "Lines of the file "$1 $arg1
	echo "Lines of the file "$2 $arg2
elif [ "$arg1" -eq "$arg2" ]
	then
	echo "The two files have the same lines"
	echo "Lines of the two files: "$arg1 "and "$arg2
else
	echo "ERROR"
fi
exit 0

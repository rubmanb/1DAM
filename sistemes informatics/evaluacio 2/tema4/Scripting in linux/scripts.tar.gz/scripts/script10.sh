#!/bin/bash
ENDING=true
while ("$ENDING")
	do
	if [ ! -f $1 ]
		then
		touch $1
		echo "File has been created with the name "$1
	else
		read -p "Name of the file to search: " name
		if [ $1 == "$name" ]
			then
			echo "Two names are equals: $name"
			ENDING=false
		else
			echo "The names are differents"
		fi
	fi
done
exit 0

#!/bin/bash
read -p "Please. give me your name" name

echo "Hello $name, welcome to Ubuntu-Linux, this is a script."
exit 0

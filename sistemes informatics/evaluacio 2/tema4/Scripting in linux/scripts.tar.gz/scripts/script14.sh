#!/bin/bash

cont=$( ls $1 | wc -l | cut -d' ' -f 1 )

echo "$cont"

exit 0

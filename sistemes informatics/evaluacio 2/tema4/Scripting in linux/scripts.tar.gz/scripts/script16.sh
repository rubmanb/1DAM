#!/bin/bash

tfiles=$( ls | wc -l | cut -d' ' -f 1 )
max=0
echo "$tfiles"
conta=$( find . -type f -iname '*.*' | wc -l )
echo "$conta"
for i in 'ls'
	do
	echo $i
	if [ -f $i ]
		then
		cont=$( $1 | wc -l )
		echo "$cont"
		if [ "$cont" -gt "$max" ]
			then
			let max = cont
		fi

	fi
done

echo "The file with more lines has $max lines"
exit 0


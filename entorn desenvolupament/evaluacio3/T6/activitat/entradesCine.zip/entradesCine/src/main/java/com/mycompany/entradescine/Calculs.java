/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.entradescine;

/**
 *
 * @author fidel
 */
public class Calculs {
    public float calculapreu(int preunormal, int edat, boolean carnetjove) {
        float preufinal=0.0F;
        if(edat < 6) { 
            preufinal=0.0F; // menors de 6 anys no paguen
        }
        else if(edat >=6 && edat <=18) {
            preufinal=preunormal*0.5F; // entre 6 anys i 17 paguen la mitat
        }
        else if(edat >18 && edat <30) {
            if(carnetjove==true) {
                preufinal=preunormal*0.75F; // de 18 a 29 anys si tenen carnet jove
                // tenen un 25% de descompte
            }
            else {
                preufinal=preunormal;
           
            }
        }
        else if(edat >=30 && edat <65) {
            preufinal=preunormal; // entre 30 i 64 anys paguen normal
        }
        else if(edat >=65) {
            preufinal=0.30F*preunormal; // amb 65 anys o més tenen 70% de descompte
        }
        return preufinal;
    }
}
